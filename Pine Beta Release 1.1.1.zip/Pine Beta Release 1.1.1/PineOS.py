import sys
def PineOS():
    print('''READY FOR USE
VERSION 1.1.1 BETA
SOME FUNCTIONS NOT WORKING
ENTER''')
    def help1():
        print("fileWrite: Create or edit a file \n\
fileRead: Print off the contents of a file \n\
evalPy: Allows user to execute simple Python programs \n\
quitPine: Quits the PineOS shell* \n\
help: Lists all currently available commands \n\
pyFile: allows for the use of an external file to be used as a application\n\
calcEval: a simple calculator\n\
*Only For testing purposes")
        program()
    def evalPy():
        try:
            eval(input("Input Python code: "))
            program()
        except:
            print("Oops, something went wrong")
            program()
    def fileWrite():
        try:
            file = open("/Users/<enter user address>/Desktop/Pine Beta Release 1.1.1/files/%s.txt" % (input("Choose a file name: ")), 'w')
            file.write(input("Enter Text to go to that file: "))
            file.close()
            program()
        except:
            print("Oops, something went wrong")
            program()
    def fileRead():
        try:
            print(open("/Users/<enter user address>/Desktop/Pine Beta Release 1.1.1/files/%s.txt" % (input("Choose a file name: ")), "r").read())
            program()
        except:
            print("Oops, something went wrong")
            program()
    def calcPlus():
        try:
            print(eval(input("Enter an equation \n")))
            program()
        except:
            print("Oops, something went wrong")
            program()
    def pyFile():
        try:
            file = open(input("Enter file directory: "), 'r')
            eval(file)
            program()
        except:
            print("Oops, something went wrong")
            program()
    def program():
        selection = input("")
        if selection == 'fileRead':
            fileRead()
        elif selection == 'fileWrite':
            fileWrite()
        elif selection == 'evalPy':
            evalPy()
        elif selection == 'help':
            help1()
        elif selection == 'quitPine' :
            sys.exit()
        elif selection == 'pyFile' :
            pyFile()
        elif selection == 'calcEval' :
            calcPlus()
        else:
            print("Error: no PineOS function called \"%s\"" %(selection))
            program()
    program()
PineOS()
